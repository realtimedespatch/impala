package @project.package.name@.@main.project.name@;

public interface MessageService {

    public String getMessage();
    
}
